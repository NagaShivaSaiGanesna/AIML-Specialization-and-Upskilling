# Shiva's Transformation Tracker

## How to run locally

1. Install Python 3.10+
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the app:
   ```
   streamlit run app.py
   ```
4. Open browser at http://localhost:8501

## Deploy on Streamlit Cloud (free, keeps progress)

1. Push this folder to a GitHub repo
2. Go to https://share.streamlit.io
3. Connect your GitHub repo
4. Set main file as `app.py`
5. Deploy — your app is live!

## Progress persistence
- Progress saves to `shiva_progress.json` in the same folder
- On Streamlit Cloud, use st.secrets or a database for permanent storage
- Locally: file persists between sessions automatically

## Features
- Daily schedule with timings
- Exact meal weights for each day
- Exercise checklist with sets/reps/rest
- Steps tracker (10K daily goal)
- Live fat burned calculator
- Weight log & progress tracking
- 90-day roadmap
- Shopping list & rules
